# RETRACE — portable recorded replay export

Original run files preserved; report and evidence index reconstructed. Original ZIP unavailable.

Recorded model run — replay, no new inference.

Run: `20261009T123704Z-8e4e19` · Sample: `vr_4b921c5d`

**FAIL**: Forbidden change with visual evidence: R1 (D1), SCENE (D1).

## Original screenshots

[Reference](images/reference.png) · [Candidate](images/candidate.png)

## Recorded observations

### R1 — forbidden

The large wooden barrel has disappeared from the wooden stand.

Rules: D1

The large wooden barrel has disappeared from the wooden stand, leaving only a couple of small wooden blocks.

[Reference crop](crops/R1_ref.png) · [Candidate crop](crops/R1_cand.png)

## Recorded whole-scene audit

The wooden barrel inside the yellow box R1 has disappeared in the AFTER image.

The wooden barrel inside the yellow box R1 has disappeared in the AFTER image, representing a missing scene element.

## Provenance

Stored rules: [rules.yaml](rules.yaml). Exact recorded model/runtime identity is preserved in analysis.json and runtime-identity.json.

Original source ZIP is unavailable; this archive is not byte-identical to it. All original file hashes are listed in package.json and evidence.json.

VideoGameQA-Bench screenshots: CC BY 4.0. https://huggingface.co/datasets/taesiri/VideoGameQA-Bench
